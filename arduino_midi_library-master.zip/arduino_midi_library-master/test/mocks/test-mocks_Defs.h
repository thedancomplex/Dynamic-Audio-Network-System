#pragma once

#include "test-mocks.h"
#include <inttypes.h>

BEGIN_TEST_MOCKS_NAMESPACE

typedef uint8_t uint8;

END_TEST_MOCKS_NAMESPACE
